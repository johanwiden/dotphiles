# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function, unicode_literals
__license__   = 'GPL v3'
__copyright__ = '2016,2017,2018,2019,2020 DaltonST <DaltonShiTzu@outlook.com>'
__my_version__ = "1.0.170"   #Technical changes after Python 3.8 testing with Calibre 4.99.3

from polyglot.builtins import as_unicode

def add_js_pseudonyms(my_db, my_cursor,DEBUG):
    #----------------------
    try:
        my_cursor.execute("begin")
        mysql = "\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('A.A. Craig','Poul Anderson');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('A.A. Fair','Erle Stanley Gardner');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Aapeli','Simo Puupponen');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Aaron Wolfe','Dean Koontz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Abigail Van Buren','Jeanne Phillips');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Abigail Van Buren','Pauline Phillips');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Abram Tertz','Andrei Sinyavsky');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Abu Nuwas','Hasin Ibn Hani Al Hakami');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Acton Bell','Anne Brontë');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Adam Chase','Paul W. Fairman');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Alan Aumbry','Barrington Bayley');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Alan Burt Ackers','Kenneth Bulmer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Alan Burt Akers','Kenneth Bulmer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Alan Gould','Victor Canning');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Alan Payne','John Jakes');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Alberto Moravia','Alberto Pincherle');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Alcofribas Nasier','François Rabelais');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Alex Kava','Sharon M. Kava');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Alexander Kent','Douglas Reeman');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Algoth Tietäväinen','Algot Untola');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Alice Addertongue','Benjamin Franklin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Amanda Cross','Carolyn Gold Heilbrun');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Amanda Quick','Jayne Ann Krentz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Anatole France','Jacques Anatole François Thibault');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Andrej Zivor','Andrej Tisma');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Andrew Macdonald','William Luther Pierce');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Anne Chaplet','Cora Stephan');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Anne Knish','Arthur Davison Ficke');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Anne Perry','Juliet Marion Hulme');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Anne Rice','Howard Allen Frances O''Brien');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Anonymous','Joe Klein');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Anson Macdonald','Robert A. Heinlein');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Anthony Afterwit','Benjamin Franklin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Anthony Ayes','William Sambrot');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Anthony Boucher','William Anthony Parker White');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Anthony Burgess','John Anthony Burgess Wilson');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Anthony Circus','Edward D. Hoch');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Anthony Corvais','Ray Bradbury');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Anthony Gilbert','Lucy Beatrice Malleson');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Anthony North','Dean Koontz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Antosha Chekhonte','Anton Chekhov');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Arkon Daraul','Idries Shah');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Artemus Ward','Charles Farrar Browne');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Arthur Allport','Raymond Z. Gallun');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Arthur Cooke','Robert W. Lowndes');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Aunt Peggy','Russell Winterbotham');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ayn Rand','Alisa Zinov''Yevna Rosenbaum');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Azorín','José Martínez Ruiz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('B.B.','Denys Watkins-Pitchford');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ba Jin','Li Yaotang');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Banaphul','Balai Chand Mukhopadhyay');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Barbara Michaels','Barbara Mertz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Barbara Vine','Ruth Rendell');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Bartholomew Gill','Mark C. Mcgarrity');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Benevolus','Benjamin Franklin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Berrintho','Robert Roberthin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Bert Parker','Harlan Ellison');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Bill Peters','William McGivern');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Blaise Cendrars','Frédéric Louis Sauser');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Bob Hart','Al Trace');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Boris Akunin','Grigory Shalvovich Chkhartishvili');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Boz','Charles Dickens');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Boz','Raymond Burrell');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Branch Cabell','James Branch Cabell');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Branislav Nušic','Alkibijad Nuša');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Brian Coffey','Dean Koontz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Brian Craig','Brian Stableford');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Brynjolf Bjarme','Henrik Ibsen');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Busy Body','Benjamin Franklin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('C. Dean Andersson','Asa Drake');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('C.H. Thames','Milton Lesser');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('C.L. Anderson','Sarah Zettel');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('C.S. Forester','Cecil Smith');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Caelia Shortface','Benjamin Franklin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Caleb Saunders','Robert A. Heinlein');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Calvin Peregoy','Thomas Calvert McClary');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Cantinflas','Fortino Mario Alfonso Moreno Reyes');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Carr Dickson','John Dickson Carr');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Carroll M. Capps','C.C. McApp');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Carter Dickson','John Dickson Carr');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Cassandra','William Connor');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Cassandra Clare','Judith Rumelt');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Catherine Aydee','Emma Tennant');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Catherine Shaw','Leila Schneps');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Cecil C. Cunningham','Ray Bradbury');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Cecil Corwin','C.M. Kornbluth');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Chan Corbett','Nathan Schachner');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Chanakya','Jawaharlal Nehru');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Charles Henry Cannell','E. Charles Vivian');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Charles Moulton','William Moulton Marston');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Charles R. Pike','Angus Wells');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Charlotte Jay','Geraldine Halls');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Charlotte Prentiss','Charles Platt');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Cherry Wilder','Cherry Barbara Grimm');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Cherubina De Gabriak','Elisaveta Ivanovna Dmitrieva');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Chris Carlsen','Robert Holdstock');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Christopher Carpenter','Christopher Evans');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Christopher Pike','Kevin Christopher Mcfadden');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Chuck Adams','E.C. Tubb');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Clare Coleman','M. Coleman Easton');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Clark Collins','Mack Reynolds');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Clem Watts','Al Trace');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Clinton Ames','Rog Phillips');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Clive Hamilton','C.S. Lewis');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Clyde Crane Campbell','Horace Gold');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Colin Andrews','F. Paul Wilson');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Compton N. Crook','Stephen Tall');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Cordwainer Smith','Paul M.A. Linebarger');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Currer Bell','Charlotte Brontë');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Curt Cannon','Ed McBain');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Curt Clark','Donald Westlake');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Curzio Malaparte','Kurt Erich Suckert');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Damon Castle','Richard R. Smith');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Dan Chernenko','Harry Turtledove');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Dan Crow','Ernest Aris');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Daniel Defoe','Daniel Foe');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Daniil Kharms','Daniil Ivanovich Yuvachev');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Danuta De Rhodes','Dan Rhodes');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('David Anderson','Raymond F. Jones');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('David Andreissen','D.C. Poyer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('David Axton','Dean Koontz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('David Michaels','Raymond Benson');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Dazai Osamu','Shuji Tsushima');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Deanna Dwyer','Dean Koontz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Dennis Clive','John Russel Fearn');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Derek Page','Arthur Porges');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Derral Pilgrim','Hugh Zachary');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Derry Tiger','Harlan Ellison');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Diablo Cody','Brook Busey');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Diedrich Knickerbocker','Washington Irving');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Dirk Clinton','Robert Silverberg');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Dom Passante','John Russel Fearn');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Dominique Aury','Anne Desclos');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Douglas Spaulding','Ray Bradbury');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Dr. Seuss','Theodor Seuss Geisel');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Dray Prescot','Kenneth Bulmer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('E. Cunningham','Ray Bradbury');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('E.L. James','Erika Leonard');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('E.V. Cunningham','Howard Fast');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Earl Titan','John Russel Fearn');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Eckhart Tolle','Ulrich Leonard Tolle');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ed Mcbain','Evan Hunter');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ed Mcbain','Salvatore A. Lombino');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Edgar Box','Gore Vidal');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Edith Van Dyne','L. Frank Baum');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Edmond Dantès','John Hughes');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Edogawa Ranpo','Taro Hirai');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Edward Charles','Edward Charles Edmond Hemsted');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Edward Plunkett','Lord Dunsany');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Edward Thomson','E.C. Tubb');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Edwin Caskoden','Charles Major');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Elia','Charles Lamb');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Elizabeth Peters','Barbara Mertz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ellery Queen','Frederic Dannay');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ellery Queen','Manfred B. Lee');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ellis Bell','Emily Brontë');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ellis Peters','Edith Pargeter');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Elroy Arno','Leroy Yerxa');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Elsa Triolet','Elsa Kagan');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Elsie J. Oxenham','Elsie Jeanette Dunkerley');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Elton V. Andrews','Frederik Pohl');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Emanuel Morgan','Witter Bynner');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Emma Lathen','Martha Henissart');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Emma Lathen','Mary Jane Latsis');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Enna Duval','Anne Hampton Brewster');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Eric Iverson','Harry Turtledove');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Erich Maria Remarque','Erich Paul Remark');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Erin Hunter','Cherith Baldry');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Erin Hunter','Kate Cary');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Erin Hunter','Victoria Holmes');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ernest Corley','Kenneth Bulmer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Euphrosyne','Julia Nyberg');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('F.W. Armstrong','T.M. Wright');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('F.W. Paul','Paul W. Fairman');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Felicia Andrews','Charles L. Grant');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Fergie','Stacy Ann Ferguson');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Flann O''Brien','Brian O''Nolan');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ford Madox Ford','Ford Hermann Hueffer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Francis Amery','Brian Stableford');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Francis Bennett','Edwin Keppel Bennett');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Francis Parnell','Festus Pragnell');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Frank Anmar','William F. Nolan');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Frank Patton','Raymond A. Palmer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Franklin W. Dixon','Leslie Mcfarlane');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Françoise Sagan','Françoise Quoirez');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Gabriela Mistral','Lucila Godoy Alcayaga');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Geoffrey Armstrong','John Russel Fearn');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Geoffrey Crayon','Washington Irving');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('George Eliot','Mary Ann Evans');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('George Groth','Martin Gardner');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('George Orwell','Eric Arthur Blair');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('George Sand','Amandine Lucie Aurore Dupin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Georges Courteline','Georges Victor Marcel Moinaux');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Gerald Wiley','Ronnie Barker');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Gilles d''Argyre','Gerard Klein');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Gordon Aghill','Randall Garrett');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Grace Corren','Robert Hoskins');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Grace Greenwood','Sara Jane Lippincott');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Graham Conway','Donald A. Wollheim');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Grant Naylor','Doug Naylor');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Grant Naylor','Rob Grant');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Greg Conrad','Rog Phillips');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Gregory Ashe','Guy Adams');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Grendon Alzee','Arthur Leo Zagat');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Guillaume Apollinaire','Wilhelm Albert Wlodzimierz Apolinary Kostrowicki');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Gulzar','Sampooran Singh Kalra');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Guthrie Paine','F. Orlin Tremaine');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Guy Amory','Ray Bradbury');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Guy Archette','Chester S. Geier');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Gérard De Nerval','Gérard Labrunie');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('H. Paget-Lowe','H.P. Lovecraft');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('H.D.','Hilda Doolittle');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('H.E. Sayeh','Hushang Ebtehaj');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('H.N. Turtletaub','Harry Turtledove');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Hall Thornton','Robert Silverberg');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Hard Pan','Geraldine Bonner');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Harold Robbins','Harold Rubin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Harry Crosby','Christopher Anvil');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Havank','Hans Van Der Kallen');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Henry Cecil','David Keller');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Henry De Costa','Frederik Pohl');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Henry Handel Richardson','Ethel Florence Lindesay Richardson');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Henry Wade','Henry Aubrey-Fletcher');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Herblock','Herbert Lawrence Block');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Hergé','Georges Remi');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Hertzan Chimera','Mike Philbin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Hugh Conway','Frederick John Fargus');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Hunt Collins','Ed McBain');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Iceberg Slim','Robert Beck');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ilkka Remes','Petri Pykälä');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ilya Ilf','Ilya Arnoldovich Faynzilberg');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ion Barbu','Dan Barbilian');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Irmari Rantamala','Algot Untola');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Irwin Shaw','Irwin Shamforoff');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Isak Dinesen','Karen Blixen');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Italo Svevo','Aron Ettore Schmitz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ivar Towers','Richard Wilson');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('J. Prescot','Kenneth Bulmer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('J.D. Austin','Joshua Dann');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('J.D. Robb','Nora Roberts');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('J.F. Clarkson','E.C. Tubb');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('J.I. Vatanen','Algot Untola');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('J.K. Rowling','Joanne Kathleen Rowling');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('J.L. Powers','John S. Glasby');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('J.W. Pelike','Raymond A. Palmer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jack Arnett','Mike McQuay');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jack Campbell','John Hemry');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jack Kirby','Jacob Kurtzberg');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jackson Cole','Barry Cord');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jael Cracken','Brian Aldiss');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('James Aston','T.H. White');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('James Axler','Laurence James');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('James Cawthorn','Philip James');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('James Clemens','Jim Czajkowski');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('James Colvin','Michael Moorcock');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('James Dillinger','James Robert Baker');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('James Herriot','James Alfred Wight');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('James Richard Cook','Rick Cook');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('James S.A. Corey','Daniel Abraham');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('James Tiptree','Alice Bradley Sheldon');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jay Charby','Harlan Ellison');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jay Livingston','Jacob Harold Levison');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jean Paul','Johann Paul Friedrich Richter');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jean Plaidy','Eleanor Hibbert');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jean Ray','Raymundus Joannes De Kremer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jeff Cooper','Gardner F. Fox');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jennifer Plum','Michael Kurland');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jeremy Bishop','Jeremy Robinson');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jesse Peel','Steve Perry');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jin Yong','Louis Cha Leung-Yung');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Johann Joachim Sautscheck','Roman Turovsky-Savchuk');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Abbott','Ed McBain');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Adams','John S. Glasby');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Almquist','Victor W. Appleton');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Alvarez','Lester Del Rey');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Arnold','Frederik Arnold Kummer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Beynon','John Wyndham Parkes Lucas Beynon Harris');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Christopher','Samuel Youd');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Cleve','Andrew J. Offutt');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Cody','Ed Earl Repp');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Coleridge','Eando Binder');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Cotton','John Russell Fearn');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Cutter','John Shirley');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Hill','Dean Koontz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Lange','Michael Crichton');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Le Carré','David John Moore Cornwell');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Oxymore','J.R.R. Tolkien');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Pease','Ralph Milne Farley');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Riverside','Robert A. Heinlein');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Sedges','Pearl S. Buck');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John T. Philliphent','John Rackham');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Tigges','William Essex');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John Wyndham','John Wyndham Parkes Lucas Beynon Harris');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('John York Cabot','David Wright O''Brian');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jonathan Oldstyle','Washington Irving');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jordan Park','Frederik Pohl');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Joseph Conrad','Józef Teodor Konrad Korzeniowski');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Joseph Howard','Paul Rudnick');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Josephine Tey','Elizabeth Mackintosh');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Joyce Churchill','M. John Harrison');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Juan Perez','Manly Wade Wellman');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Jud Cary','E.C. Tubb');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Juhani Tervapää','Hella Wuolijoki');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Julia Quinn','Julia Pottinger');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Justin Case','Hugh B. Cave');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('K. Hardesh','Clement Greenberg');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('K. Thomas','John Russel Fearn');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('K.R. Dwyer','Dean Koontz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ka-Tsetnik','Yehiel De-Nur');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Katheryn Atwood','Kathryn Ptacek');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Kenneth Pembrooke','Gerald W. Page');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Kenneth Putnam','William Tenn');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Kennilworthy Whisp','J.K. Rowling');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Kilgore Trout','Philip Jose Farmer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Kir Bulychov','Igor Vsevolodovich Mozheiko');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Korney Chukovsky','Nikolay Vasilyevich Korneychukov');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('L.C. Powers','E.C. Tubb');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Laurence Appleton','H.P. Lovecraft');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lawrence Chandler','Howard Browne');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lawrence Talbot','Edward Bryant');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lazlo Toth','Don Novello');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lee Archer','Harlan Ellison');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lee Arthur Chane','Edward Willett');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lee Chapman','Marion Zimmer Bradley');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lee Correy','G. Harry Stine');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Leigh Nichols','Dean Koontz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lemony Snicket','Daniel Handler');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Leo Tincrowder','Philip Jose Farmer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Leonard Chris','Dean Koontz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Leslie Charteris','Leslie Charles Bowyer-Yin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lester Del Rey','Leonard Knapp');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Levi Crow','Manly Wade Wellman');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lewis Allan','Abel Meeropol');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lewis Carroll','Charles Lutwidge Dodgson');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lewis Padgett','C.L. Moore');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lewis Padgett','Henry Kuttner');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lewis Theobold, Jr.','H.P. Lovecraft');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Liisan-Antti Ja Jussi Porilainen','Algot Untola');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lobsang Rampa','Cyril Henry Hoskin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Loius J. Adams','Joe L. Hensley');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lorenzo Da Ponte','Emmanuele Conegliano');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Louis Preston','E.C. Tubb');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Louis-Ferdinand Céline','Louis-Ferdinand Destouches');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lu Xun','Zhou Shuren');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lucas Parker','John Wyndham');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lydia Koidula','Lydia Emilie Florentine Jannsen');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lyle Monroe','Robert A. Heinlein');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Lyn Triffitt','Lyn Battersby');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('M. Barnard Eldershaw','Flora Eldershaw');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('M. Barnard Eldershaw','Marjorie Barnard');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('M.E. Chaber','Kendell Foster Crossen');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('M.R. Blackwell','Richard Sylvan Selzer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Maarten Maartens','Jozua Marius Willem Van Der Poorten Schwartz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Maddox','George Ouzounian');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Madeleine Brent','Peter O''Donnell');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Maggy Thomas','Emily Devenport');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Maiju Lassila','Algot Untola');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Maironis','Jonas Maciulis');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Mao Dun','Shen Dehong');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Margaret Allan','W.T. Quick');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Maria Palmer','Lisa Tuttle');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Mark Brandis','Nikolai Von Michalewsky');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Mark Phillips','Laurence M. Janifer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Mark Twain','Samuel Langhorne Clemens');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Martha Careful','Benjamin Franklin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Martha Conley','Marta Randall');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Martin Pearson','Donald A. Wollheim');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Marton Taiga','Martti Löfberg');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Mary Westmacott','Agatha Christie');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Max Stirner','Johann Kaspar Schmidt');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Maxwell Grant','Walter B. Gibson');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Maxwell Trent','Arthur Porges');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Megan Lindholm','Margaret Astrid Lindholm Ogden');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Michael Arlen','Dikran Kuyumjian');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Michael Corbin','Cleve Cartmill');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Michael Innes','J.I.M. Stewart');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Michael Phillips','Charles Beaumont');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Michael Serafian','Malachi Martin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Migjeni','Millosh Gjergj Nikolla');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Miles Cramer','Thomas Calvert McClary');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Miss Manners','Judith Martin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Molière','Jean Baptiste Poquelin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Morton D. Paley','Sam Merwin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Multatuli','Eduard Douwes Dekker');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Murray Leinster','William Fitzgerald Jenkins');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('N.W. Clerk','C.S. Lewis');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Nancy Boyd','Edna St. Vincent Millay');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Nathan Aldyne','Michael P. Kube-McDowell');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Nathan Archer','Lawrence Watt-Evans');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Natsume Soseki','Natsume Kinnosuke');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Newt Scamander','J.K. Rowling');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Nicci French','Nicci Gerard And Sean French');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Nick Carter','Martin Cruz Smith');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Nicolas Blake','Cecil Day-Lewis');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Nino Culotta','John O''Grady');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Nisa','Nicola Salerno');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Noam D. Pellume','Orson Scott Card');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Novalis','Georg Philipp Friedrich Freiherr Von Hardenberg');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('O. Henry','William Sydney Porter');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ogdred Weary','Edward Gorey');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Onoto Watanna','Winnifred Eaton');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ouida','Marie Louise De La Ramée');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Owen West','Dean Koontz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('P. Mustapää','Martti Haavio');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('P.F. Costello','William P. McGivern');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('P.L. Travers','Helen Goff');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Pablo Neruda','Ricardo Eliecer Neftalí Reyes Basoalto');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Pat Frank','Harry Hart Frank');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Patience Strong','Winifred Emma May');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Paul Annixter','Howard Allison Sturtzel');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Paul Ash','Pauline Whitby');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Paul Celan','Paul Antschel');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Paul Chapin','Philip Jose Farmer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Paul French','Isaac Asimov');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Paul Éluard','Eugène Grindel');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Pauline Réage','Anne Desclos');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Pel Torro','Robert L. Fanthorpe');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Perez Hilton','Mario Armando Lavandeira');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Peter Arthur','Arthur Porges');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Peter Gast','Heinrich Köselitz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Peter Macalan','Peter Berresford Ellis');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Peter Phillips','Howard Browne');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Peter Tremayne','Peter Berresford Ellis');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Peyo','Pierre Culliford');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Philip Guston','Phillip Goldstein');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Pierre Loti','Louis Marie Julien Viaud');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Piers Anthony','Piers Anthony Dillingham Jacob');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Pisanus Fraxi','Henry Spencer Ashbee');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Polly Baker','Benjamin Franklin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Polton Cross','John Russel Fearn');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Price Curtis','Harlan Ellison');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Q.','Arthur Quiller-Couch');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Quentin Thomas','W.T. Quick');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Quinn Fawcett','Bill Fawcett');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Quinn Fawcett','Chelsea Quinn Yarbro');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('R.E. Porter','Edward D. Hoch');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Raccoona Sheldon','Alice Bradley Sheldon');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ray Ainsbury','A. Hyatt Verrill');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Rehmat Farrukhabadi','Muhammad Rehmatullah Qureshi');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Renfrew Pemberton','F.M. Busby');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Rhys Bowen','Janet Quin-Harkin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Richard Austin','Victor Milan');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Richard Avery','Edmund Cooper');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Richard Awlinson','Scott Ciecin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Richard Bachman','Stephen King');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Richard Casey','Leroy Yerxa');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Richard Leander','Richard Von Volkmann');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Richard Paige','Dean Koontz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Richard Peyton','Peter Haining');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Richard Phillips','Philip K. Dick');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Richard Saunders','Benjamin Franklin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Richard Stark','Donald E. Westlake');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Robert Arnette','Chester S. Geier');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Robert Cain','William H. Keith');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Robert Castle','Edmond Hamilton');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Robert Courtney','Harlan Ellison');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Robert Galbraith','J.K. Rowling');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Robert Jordan','James Oliver Rigney');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Robert Markham','Kingsley Amis');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Robert O. Saber','Milton K. Ozaki');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Robert Player','Robert Jordan');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Robert Touzalin','Robert Reed');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Roberta Cray','Ru Emerson');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Robin A. Hood','Ernest Aris');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Robin Hobb','Margaret Astrid Lindholm Ogden');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Robyn Tallis','Mary Frances Zambreno');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Roger Arcot','Robert D. Locke');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Roger D. Ayecock','Roger Dee');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Roger Fairbairn','John Dickson Carr');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Romain Gary','Romain Kacew');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ron Archer','D. Van Arnam');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ross Franklyn','Frank Hardy');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Rothayne Amare','S.J. Byrne');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Roxanne Conrad','Rachel Caine');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Rupert Clinton','Kenneth Bulmer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('S.M. Tenneshaw','Robert Silverberg');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('S.S. Van Dine','Willard Huntington Wright');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Saint-John Perse','Alexis Saint-Léger');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Saki','Hector Hugh Munro');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Salomeja Neris','Salomeja Bucinskaite-Buciene');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Sam Allison','Noel Loomis');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Sannois','Camille Saint-Saëns');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Sapper','H.C. Mcneile');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Sapphire','Ramona Lofton');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Seth F. Henriett','Fajcsák Henrietta');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Shahriar','Mohammad-Hossein Shahriar');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Shale Aaron','Robert Boswell');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Shane Christopher','Matthew J. Costello');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Shawn Haigins','Ashwin Sanghi');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Sidney Sheldon','Sidney Schechtel');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Silence Dogood','Benjamin Franklin');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Simon Anthony','Miles J. Breuer');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Simon York','Robert A. Heinlein');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Sister Nivedita','Margaret Elizabeth Noble');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Sjón','Sigurjón Birgir Sigurðsson');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Sonny Powell','Alfred Bester');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Stan Lee','Stanley Martin Lieber');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Steele Rudd','Arthur Hoey Davis');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Stefan Brockhoff','Dieter Cunz');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Stein Riverton','Sven Elvestad');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Stendhal','Marie-Henri Beyle');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Steven Charles','Charles L. Grant');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Student','William Sealy Gosset');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Sue Denim','Dav Pilkey');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Sui Sin Far','Edith Maude Eaton');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('T.H. Lain','Philip Athans');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('T.M. Maple','Jim Burke');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Ted L. Nancy','Barry Marder');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Theo Lesieg','Dr. Seuss');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Theodore Pine','Henry Hasse');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Thoinot Arbeau','Jehan Tabourot');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Thomas Calvert','Thomas Calvert McClary');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Thomas Pendleton','Lee Thomas');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Thornton Ayre','John Russel Fearn');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Timothy Shy','D.B. Wyndham Lewis');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Tite Kubo','Noriaki Kubo');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Toegye','Yi Hwang');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Tom Tomorrow','Dan Perkins');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Toni Morrison','Chloe Anthony Wofford');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Tony Anzetti','Ann Tonsor Zeddies');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Tori Carrington','Tony Karayianni');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Trebor Thorpe','Robert L. Fanthorpe');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Trevanian','Rodney William Whitaker');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Tristan Tzara','Sami Rosenstock');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Tudor Arghezi','Ion N. Theodorescu');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Uanhenga Xitu','Agostinho André Mendes De Carvalho');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Umberto Saba','Umberto Poli');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Uriah Fuller','Martin Gardner');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('V.C. Andrews','Andrew Neiderman');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Vanessa Pryor','Chelsea Quinn Yarbro');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Vazha','Luka Razikashvili');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Vera Haij','Tove Jansson');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Vercors','Jean Bruller');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Vernon Sullivan','Boris Vian');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Victor Appleton','Robert Vardeman');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Victoria Lucas','Sylvia Plath');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Vladimir Sirin','Vladimir Nabokov');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Voltaire','François-Marie Arouet');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Väinö Stenberg','Algot Untola');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('W.N.P. Barbellion','Bruce Frederick Cummings');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Wade Curtis','Jerry Pournelle');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Walter','Henry Spencer Ashbee');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Walter Chapman','Robert Silverberg');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Webster Craig','Eric Frank Russell');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Wes Amherst','Richard S. Shaver');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('William Atheling, Jr.','James Blish');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('William Ayes','William Sambrot');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('William Callahan','Raymond Z. Gallun');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('William Lee','William S. Burroughs');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('William Pattrick','Peter Haining');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('William Penn','Jeremiah Evarts');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('William Tanner','Kingsley Amis');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Willibald Alexis','Georg Wilhelm Heinrich Haring');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Woody Allen','Allen Stewart Konigsberg');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Wyndham Parkes','John Wyndham');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Yevgeny Petrov','Yevgeniy Petrovich Kataev');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Yukio Mishima','Hiraoka Kimitake');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Æ.','George William Russell');\
            INSERT OR IGNORE INTO _js_pseudonyms VALUES('Émile Ajar','Romain Gary');\
            "
        my_cursor.execute (mysql)
        my_cursor.execute("commit")
        msg = "JS: Pseudonym Table Has Been Created and Populated with Default Values."
        if DEBUG: print(msg)
        return True,msg
    except Exception as e:
        msg = as_unicode(e)
        if DEBUG: print("JS pseudonym sql objects error: ", msg)
        return False,msg
